# importing the necessary dependencies
from flask import Flask, render_template, request,jsonify
from flask_cors import CORS,cross_origin
import pandas as pd
import pickle
import numpy as np
import xgboost
from sklearn.preprocessing import StandardScaler


app = Flask(__name__) # initializing a flask app


train_set = pd.read_csv('http://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data', header = None)
test_set  = pd.read_csv('http://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.test' , skiprows = 1, header = None)




@app.route('/')  # route to display the home page
@cross_origin()
def homePage():
    return render_template('index.html')


# prediction function
def ValuePredictor(to_predict_list):
    to_predict = np.array(to_predict_list).reshape(1, 14)
    loaded_model = pickle.load(open("modelForPrediction.sav", "rb"))
    result = loaded_model.predict(to_predict)
    return result[0]


@app.route('/predict',methods=['POST']) # route to show the predictions in a web UI
@cross_origin()
def result():
    if request.method == 'POST':
        to_predict_list = request.form.to_dict()
        to_predict_list = list(to_predict_list.values())
        to_predict_list = list(map(int, to_predict_list))
        result = ValuePredictor(to_predict_list)
        if int(result)== 1:
            prediction ='A person income more than 50K'
        else:
            prediction ='A person income less that 50K'
        return render_template("results.html", prediction = prediction)


if __name__ == "__main__":
    app.run(host='127.0.0.1', port=8001, debug=True)
	#app.run(debug=True) # running the app